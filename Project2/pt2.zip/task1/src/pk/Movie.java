package pk;
import java.util.ArrayList;
import java.util.Scanner;

class Movie {
    String title;
    String genre;
    int year;

    Movie(String title, String genre, int year) {
        this.title = title;
        this.genre = genre;
        this.year = year;
    }

    void display() {
        System.out.println("Title: " + title);
        System.out.println("Genre: " + genre);
        System.out.println("Year: " + year);
    }
}


