package pk;

import java.util.ArrayList;
import java.util.Scanner;

public class MovieDatabase {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        ArrayList<Movie> movies = new ArrayList<>();
	        int choice;

	        do {
	            System.out.println("\n===== Movie Database Menu =====");
	            System.out.println("1. Add Movie");
	            System.out.println("2. Search Movie");
	            System.out.println("3. Display All Movies");
	            System.out.println("4. Exit");
	            System.out.print("Enter your choice: ");
	            choice = sc.nextInt();
	            sc.nextLine(); // Clear buffer

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter Movie Title: ");
	                    String title = sc.nextLine();

	                    System.out.print("Enter Genre: ");
	                    String genre = sc.nextLine();

	                    System.out.print("Enter Release Year: ");
	                    int year = sc.nextInt();
	                    sc.nextLine();

	                    movies.add(new Movie(title, genre, year));
	                    System.out.println("Movie added successfully!");
	                    break;

	                case 2:
	                    System.out.print("Enter Movie Title to Search: ");
	                    String searchTitle = sc.nextLine();
	                    boolean found = false;

	                    for (Movie movie : movies) {
	                        if (movie.title.equalsIgnoreCase(searchTitle)) {
	                            System.out.println("\nMovie Found:");
	                            movie.display();
	                            found = true;
	                            break;
	                        }
	                    }

	                    if (!found) {
	                        System.out.println("Movie not found!");
	                    }
	                    break;

	                case 3:
	                    if (movies.isEmpty()) {
	                        System.out.println("No movies in database.");
	                    } else {
	                        System.out.println("\n===== Movie List =====");
	                        for (Movie movie : movies) {
	                            movie.display();
	                            System.out.println("------------------");
	                        }
	                    }
	                    break;

	                case 4:
	                    System.out.println("Exiting Program...");
	                    break;

	                default:
	                    System.out.println("Invalid choice!");
	            }

	        } while (choice != 4);

	        sc.close();
	    }
	}

	